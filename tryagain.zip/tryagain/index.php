<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
echo "Welcome, " . $_SESSION['username'];
?>
<a href="upload.php">Upload File</a>
<a href="view_files.php">View Files</a>
<a href="logout.php">Logout</a>
